﻿namespace Projeto02.Views
{
    partial class frmDesenvolvedoraCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desenvolvedorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realizarVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itensDaVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnApagarDesenvolvedora = new System.Windows.Forms.Button();
            this.btnSalvarDesenvolvedora = new System.Windows.Forms.Button();
            this.lblCodigoDesenvolvedora = new System.Windows.Forms.Label();
            this.lblNomeResponsavelDesenvolvedora = new System.Windows.Forms.Label();
            this.txtCodigoDesenvolvedora = new System.Windows.Forms.TextBox();
            this.txtEmailDesenvolvedora = new System.Windows.Forms.TextBox();
            this.lblEmailDesenvolvedora = new System.Windows.Forms.Label();
            this.lblCidadeDesenvolvedora = new System.Windows.Forms.Label();
            this.lblPaisDesenvolvedora = new System.Windows.Forms.Label();
            this.lblTelefoneDesenvolvedora = new System.Windows.Forms.Label();
            this.dtpFundacaoDesenvolvedora = new System.Windows.Forms.DateTimePicker();
            this.lblDataFundacaoDesenvolvedora = new System.Windows.Forms.Label();
            this.lblNomeDesenvolvedora = new System.Windows.Forms.Label();
            this.txtNomeResponsavelDesenvolvedora = new System.Windows.Forms.TextBox();
            this.txtTelefoneDesenvolvedora = new System.Windows.Forms.TextBox();
            this.txtCidadeDesenvolvedora = new System.Windows.Forms.TextBox();
            this.categoriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jogosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.jogosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jogosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtPaisDesenvolvedora = new System.Windows.Forms.TextBox();
            this.txtNomeDesenvolvedora = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.clientesToolStripMenuItem.Text = "Clientes";
            // 
            // desenvolvedorasToolStripMenuItem
            // 
            this.desenvolvedorasToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.desenvolvedorasToolStripMenuItem.Name = "desenvolvedorasToolStripMenuItem";
            this.desenvolvedorasToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.desenvolvedorasToolStripMenuItem.Text = "Desenvolvedoras";
            this.desenvolvedorasToolStripMenuItem.Click += new System.EventHandler(this.desenvolvedorasToolStripMenuItem_Click);
            // 
            // vendasToolStripMenuItem
            // 
            this.vendasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.realizarVendaToolStripMenuItem,
            this.consultarVendaToolStripMenuItem,
            this.itensDaVendaToolStripMenuItem});
            this.vendasToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.vendasToolStripMenuItem.Name = "vendasToolStripMenuItem";
            this.vendasToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.vendasToolStripMenuItem.Text = "Vendas";
            // 
            // realizarVendaToolStripMenuItem
            // 
            this.realizarVendaToolStripMenuItem.Name = "realizarVendaToolStripMenuItem";
            this.realizarVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.realizarVendaToolStripMenuItem.Text = "Realizar Venda";
            // 
            // consultarVendaToolStripMenuItem
            // 
            this.consultarVendaToolStripMenuItem.Name = "consultarVendaToolStripMenuItem";
            this.consultarVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.consultarVendaToolStripMenuItem.Text = "Consultar Venda";
            // 
            // itensDaVendaToolStripMenuItem
            // 
            this.itensDaVendaToolStripMenuItem.Name = "itensDaVendaToolStripMenuItem";
            this.itensDaVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.itensDaVendaToolStripMenuItem.Text = "Itens da Venda";
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.funcionáriosToolStripMenuItem.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label1.Location = new System.Drawing.Point(601, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 27);
            this.label1.TabIndex = 87;
            this.label1.Text = "CADASTRO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label3.Location = new System.Drawing.Point(644, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 27);
            this.label3.TabIndex = 89;
            this.label3.Text = "DE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label2.Location = new System.Drawing.Point(555, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(227, 27);
            this.label2.TabIndex = 88;
            this.label2.Text = "DESENVOLVEDORA";
            // 
            // btnApagarDesenvolvedora
            // 
            this.btnApagarDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.btnApagarDesenvolvedora.FlatAppearance.BorderSize = 0;
            this.btnApagarDesenvolvedora.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApagarDesenvolvedora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagarDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(86)))), ((int)(((byte)(216)))));
            this.btnApagarDesenvolvedora.Location = new System.Drawing.Point(649, 407);
            this.btnApagarDesenvolvedora.Name = "btnApagarDesenvolvedora";
            this.btnApagarDesenvolvedora.Size = new System.Drawing.Size(88, 26);
            this.btnApagarDesenvolvedora.TabIndex = 86;
            this.btnApagarDesenvolvedora.Text = "Apagar";
            this.btnApagarDesenvolvedora.UseVisualStyleBackColor = false;
            this.btnApagarDesenvolvedora.Click += new System.EventHandler(this.btnApagarDesenvolvedora_Click);
            // 
            // btnSalvarDesenvolvedora
            // 
            this.btnSalvarDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(86)))), ((int)(((byte)(216)))));
            this.btnSalvarDesenvolvedora.FlatAppearance.BorderSize = 0;
            this.btnSalvarDesenvolvedora.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarDesenvolvedora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvarDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.btnSalvarDesenvolvedora.Location = new System.Drawing.Point(545, 407);
            this.btnSalvarDesenvolvedora.Name = "btnSalvarDesenvolvedora";
            this.btnSalvarDesenvolvedora.Size = new System.Drawing.Size(88, 26);
            this.btnSalvarDesenvolvedora.TabIndex = 85;
            this.btnSalvarDesenvolvedora.Text = "Salvar";
            this.btnSalvarDesenvolvedora.UseVisualStyleBackColor = false;
            this.btnSalvarDesenvolvedora.Click += new System.EventHandler(this.btnSalvarDesenvolvedora_Click);
            // 
            // lblCodigoDesenvolvedora
            // 
            this.lblCodigoDesenvolvedora.AutoSize = true;
            this.lblCodigoDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblCodigoDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblCodigoDesenvolvedora.Location = new System.Drawing.Point(421, 336);
            this.lblCodigoDesenvolvedora.Name = "lblCodigoDesenvolvedora";
            this.lblCodigoDesenvolvedora.Size = new System.Drawing.Size(57, 18);
            this.lblCodigoDesenvolvedora.TabIndex = 84;
            this.lblCodigoDesenvolvedora.Text = "Código";
            // 
            // lblNomeResponsavelDesenvolvedora
            // 
            this.lblNomeResponsavelDesenvolvedora.AutoSize = true;
            this.lblNomeResponsavelDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblNomeResponsavelDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeResponsavelDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblNomeResponsavelDesenvolvedora.Location = new System.Drawing.Point(423, 282);
            this.lblNomeResponsavelDesenvolvedora.Name = "lblNomeResponsavelDesenvolvedora";
            this.lblNomeResponsavelDesenvolvedora.Size = new System.Drawing.Size(164, 18);
            this.lblNomeResponsavelDesenvolvedora.TabIndex = 83;
            this.lblNomeResponsavelDesenvolvedora.Text = "Nome do Responsável";
            // 
            // txtCodigoDesenvolvedora
            // 
            this.txtCodigoDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtCodigoDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodigoDesenvolvedora.Location = new System.Drawing.Point(424, 356);
            this.txtCodigoDesenvolvedora.Multiline = true;
            this.txtCodigoDesenvolvedora.Name = "txtCodigoDesenvolvedora";
            this.txtCodigoDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtCodigoDesenvolvedora.TabIndex = 82;
            // 
            // txtEmailDesenvolvedora
            // 
            this.txtEmailDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtEmailDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmailDesenvolvedora.Location = new System.Drawing.Point(47, 356);
            this.txtEmailDesenvolvedora.Multiline = true;
            this.txtEmailDesenvolvedora.Name = "txtEmailDesenvolvedora";
            this.txtEmailDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtEmailDesenvolvedora.TabIndex = 81;
            // 
            // lblEmailDesenvolvedora
            // 
            this.lblEmailDesenvolvedora.AutoSize = true;
            this.lblEmailDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblEmailDesenvolvedora.Location = new System.Drawing.Point(44, 336);
            this.lblEmailDesenvolvedora.Name = "lblEmailDesenvolvedora";
            this.lblEmailDesenvolvedora.Size = new System.Drawing.Size(51, 18);
            this.lblEmailDesenvolvedora.TabIndex = 80;
            this.lblEmailDesenvolvedora.Text = "E-mail";
            // 
            // lblCidadeDesenvolvedora
            // 
            this.lblCidadeDesenvolvedora.AutoSize = true;
            this.lblCidadeDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblCidadeDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCidadeDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblCidadeDesenvolvedora.Location = new System.Drawing.Point(423, 229);
            this.lblCidadeDesenvolvedora.Name = "lblCidadeDesenvolvedora";
            this.lblCidadeDesenvolvedora.Size = new System.Drawing.Size(55, 18);
            this.lblCidadeDesenvolvedora.TabIndex = 79;
            this.lblCidadeDesenvolvedora.Text = "Cidade";
            // 
            // lblPaisDesenvolvedora
            // 
            this.lblPaisDesenvolvedora.AutoSize = true;
            this.lblPaisDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblPaisDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblPaisDesenvolvedora.Location = new System.Drawing.Point(44, 282);
            this.lblPaisDesenvolvedora.Name = "lblPaisDesenvolvedora";
            this.lblPaisDesenvolvedora.Size = new System.Drawing.Size(35, 18);
            this.lblPaisDesenvolvedora.TabIndex = 78;
            this.lblPaisDesenvolvedora.Text = "País";
            // 
            // lblTelefoneDesenvolvedora
            // 
            this.lblTelefoneDesenvolvedora.AutoSize = true;
            this.lblTelefoneDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefoneDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblTelefoneDesenvolvedora.Location = new System.Drawing.Point(44, 228);
            this.lblTelefoneDesenvolvedora.Name = "lblTelefoneDesenvolvedora";
            this.lblTelefoneDesenvolvedora.Size = new System.Drawing.Size(67, 18);
            this.lblTelefoneDesenvolvedora.TabIndex = 77;
            this.lblTelefoneDesenvolvedora.Text = "Telefone";
            // 
            // dtpFundacaoDesenvolvedora
            // 
            this.dtpFundacaoDesenvolvedora.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFundacaoDesenvolvedora.CalendarForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpFundacaoDesenvolvedora.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dtpFundacaoDesenvolvedora.CalendarTrailingForeColor = System.Drawing.Color.DimGray;
            this.dtpFundacaoDesenvolvedora.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFundacaoDesenvolvedora.Location = new System.Drawing.Point(424, 198);
            this.dtpFundacaoDesenvolvedora.Name = "dtpFundacaoDesenvolvedora";
            this.dtpFundacaoDesenvolvedora.Size = new System.Drawing.Size(311, 20);
            this.dtpFundacaoDesenvolvedora.TabIndex = 76;
            // 
            // lblDataFundacaoDesenvolvedora
            // 
            this.lblDataFundacaoDesenvolvedora.AutoSize = true;
            this.lblDataFundacaoDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblDataFundacaoDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataFundacaoDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblDataFundacaoDesenvolvedora.Location = new System.Drawing.Point(421, 176);
            this.lblDataFundacaoDesenvolvedora.Name = "lblDataFundacaoDesenvolvedora";
            this.lblDataFundacaoDesenvolvedora.Size = new System.Drawing.Size(135, 18);
            this.lblDataFundacaoDesenvolvedora.TabIndex = 75;
            this.lblDataFundacaoDesenvolvedora.Text = "Data de Fundação";
            // 
            // lblNomeDesenvolvedora
            // 
            this.lblNomeDesenvolvedora.AutoSize = true;
            this.lblNomeDesenvolvedora.BackColor = System.Drawing.Color.Transparent;
            this.lblNomeDesenvolvedora.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeDesenvolvedora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblNomeDesenvolvedora.Location = new System.Drawing.Point(44, 175);
            this.lblNomeDesenvolvedora.Name = "lblNomeDesenvolvedora";
            this.lblNomeDesenvolvedora.Size = new System.Drawing.Size(48, 18);
            this.lblNomeDesenvolvedora.TabIndex = 74;
            this.lblNomeDesenvolvedora.Text = "Nome";
            // 
            // txtNomeResponsavelDesenvolvedora
            // 
            this.txtNomeResponsavelDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtNomeResponsavelDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomeResponsavelDesenvolvedora.Location = new System.Drawing.Point(424, 303);
            this.txtNomeResponsavelDesenvolvedora.Multiline = true;
            this.txtNomeResponsavelDesenvolvedora.Name = "txtNomeResponsavelDesenvolvedora";
            this.txtNomeResponsavelDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtNomeResponsavelDesenvolvedora.TabIndex = 73;
            // 
            // txtTelefoneDesenvolvedora
            // 
            this.txtTelefoneDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtTelefoneDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefoneDesenvolvedora.Location = new System.Drawing.Point(47, 249);
            this.txtTelefoneDesenvolvedora.Multiline = true;
            this.txtTelefoneDesenvolvedora.Name = "txtTelefoneDesenvolvedora";
            this.txtTelefoneDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtTelefoneDesenvolvedora.TabIndex = 72;
            this.txtTelefoneDesenvolvedora.TextChanged += new System.EventHandler(this.txtTelefoneDesenvolvedora_TextChanged);
            // 
            // txtCidadeDesenvolvedora
            // 
            this.txtCidadeDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtCidadeDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCidadeDesenvolvedora.Location = new System.Drawing.Point(424, 247);
            this.txtCidadeDesenvolvedora.Multiline = true;
            this.txtCidadeDesenvolvedora.Name = "txtCidadeDesenvolvedora";
            this.txtCidadeDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtCidadeDesenvolvedora.TabIndex = 71;
            // 
            // categoriasToolStripMenuItem
            // 
            this.categoriasToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.categoriasToolStripMenuItem.Name = "categoriasToolStripMenuItem";
            this.categoriasToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
            this.categoriasToolStripMenuItem.Text = "Categorias";
            // 
            // jogosToolStripMenuItem2
            // 
            this.jogosToolStripMenuItem2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.jogosToolStripMenuItem2.Name = "jogosToolStripMenuItem2";
            this.jogosToolStripMenuItem2.Size = new System.Drawing.Size(169, 24);
            this.jogosToolStripMenuItem2.Text = "Jogos";
            // 
            // jogosToolStripMenuItem1
            // 
            this.jogosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jogosToolStripMenuItem2,
            this.categoriasToolStripMenuItem});
            this.jogosToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.jogosToolStripMenuItem1.Name = "jogosToolStripMenuItem1";
            this.jogosToolStripMenuItem1.Size = new System.Drawing.Size(71, 24);
            this.jogosToolStripMenuItem1.Text = "Jogos";
            // 
            // jogosToolStripMenuItem
            // 
            this.jogosToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.jogosToolStripMenuItem.Name = "jogosToolStripMenuItem";
            this.jogosToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.jogosToolStripMenuItem.Text = "Início";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(45)))));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jogosToolStripMenuItem,
            this.jogosToolStripMenuItem1,
            this.cadastrosToolStripMenuItem,
            this.vendasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(222, 17);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(335, 28);
            this.menuStrip1.TabIndex = 65;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            this.cadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.desenvolvedorasToolStripMenuItem});
            this.cadastrosToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            this.cadastrosToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
            this.cadastrosToolStripMenuItem.Text = "Cadastros";
            // 
            // txtPaisDesenvolvedora
            // 
            this.txtPaisDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtPaisDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPaisDesenvolvedora.Location = new System.Drawing.Point(47, 303);
            this.txtPaisDesenvolvedora.Multiline = true;
            this.txtPaisDesenvolvedora.Name = "txtPaisDesenvolvedora";
            this.txtPaisDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtPaisDesenvolvedora.TabIndex = 70;
            // 
            // txtNomeDesenvolvedora
            // 
            this.txtNomeDesenvolvedora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtNomeDesenvolvedora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomeDesenvolvedora.Location = new System.Drawing.Point(47, 196);
            this.txtNomeDesenvolvedora.Multiline = true;
            this.txtNomeDesenvolvedora.Name = "txtNomeDesenvolvedora";
            this.txtNomeDesenvolvedora.Size = new System.Drawing.Size(311, 23);
            this.txtNomeDesenvolvedora.TabIndex = 69;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(560, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 3);
            this.panel2.TabIndex = 67;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(12, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 3);
            this.panel1.TabIndex = 66;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Projeto02.Properties.Resources.banner1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(802, 124);
            this.pictureBox1.TabIndex = 68;
            this.pictureBox1.TabStop = false;
            // 
            // frmDesenvolvedoraCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnApagarDesenvolvedora);
            this.Controls.Add(this.btnSalvarDesenvolvedora);
            this.Controls.Add(this.lblCodigoDesenvolvedora);
            this.Controls.Add(this.lblNomeResponsavelDesenvolvedora);
            this.Controls.Add(this.txtCodigoDesenvolvedora);
            this.Controls.Add(this.txtEmailDesenvolvedora);
            this.Controls.Add(this.lblEmailDesenvolvedora);
            this.Controls.Add(this.lblCidadeDesenvolvedora);
            this.Controls.Add(this.lblPaisDesenvolvedora);
            this.Controls.Add(this.lblTelefoneDesenvolvedora);
            this.Controls.Add(this.dtpFundacaoDesenvolvedora);
            this.Controls.Add(this.lblDataFundacaoDesenvolvedora);
            this.Controls.Add(this.lblNomeDesenvolvedora);
            this.Controls.Add(this.txtNomeResponsavelDesenvolvedora);
            this.Controls.Add(this.txtTelefoneDesenvolvedora);
            this.Controls.Add(this.txtCidadeDesenvolvedora);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.txtPaisDesenvolvedora);
            this.Controls.Add(this.txtNomeDesenvolvedora);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmDesenvolvedoraCadastro";
            this.Text = "frmDesenvolvedora";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desenvolvedorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem realizarVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itensDaVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnApagarDesenvolvedora;
        private System.Windows.Forms.Button btnSalvarDesenvolvedora;
        private System.Windows.Forms.Label lblCodigoDesenvolvedora;
        private System.Windows.Forms.Label lblNomeResponsavelDesenvolvedora;
        private System.Windows.Forms.TextBox txtCodigoDesenvolvedora;
        private System.Windows.Forms.TextBox txtEmailDesenvolvedora;
        private System.Windows.Forms.Label lblEmailDesenvolvedora;
        private System.Windows.Forms.Label lblCidadeDesenvolvedora;
        private System.Windows.Forms.Label lblPaisDesenvolvedora;
        private System.Windows.Forms.Label lblTelefoneDesenvolvedora;
        private System.Windows.Forms.DateTimePicker dtpFundacaoDesenvolvedora;
        private System.Windows.Forms.Label lblDataFundacaoDesenvolvedora;
        private System.Windows.Forms.Label lblNomeDesenvolvedora;
        private System.Windows.Forms.TextBox txtNomeResponsavelDesenvolvedora;
        private System.Windows.Forms.TextBox txtTelefoneDesenvolvedora;
        private System.Windows.Forms.TextBox txtCidadeDesenvolvedora;
        private System.Windows.Forms.ToolStripMenuItem categoriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastrosToolStripMenuItem;
        private System.Windows.Forms.TextBox txtPaisDesenvolvedora;
        private System.Windows.Forms.TextBox txtNomeDesenvolvedora;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}