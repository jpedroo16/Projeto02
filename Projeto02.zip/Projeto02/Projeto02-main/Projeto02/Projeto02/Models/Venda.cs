﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System;

namespace Projeto02.Models
{
    public class Venda
    {
        public int venda_id { get; set; }
        public DateTime data_hora { get; set; }
        public int cliente_id { get; set; }
        public int funcionario_id { get; set; }
        public decimal valor_total { get; set; }
        public string forma_pagamento { get; set; }
        public string status_venda { get; set; }
    }
}
