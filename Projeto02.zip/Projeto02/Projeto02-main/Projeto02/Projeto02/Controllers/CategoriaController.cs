﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class CategoriaController
    {
        private DataBaseSqlServer banco;

        public CategoriaController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Categoria categoria)
        {
            string sql = "INSERT INTO Categoria " +
                "(nome, descricao, classificacao_indicativa, faixa_etaria, publico_alvo, data_cadastro) " +
                "VALUES (@nome, @descricao, @classificacao_indicativa, @faixa_etaria, @publico_alvo, @data_cadastro)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@nome", categoria.nome);
                comando.Parameters.AddWithValue("@descricao", categoria.descricao);
                comando.Parameters.AddWithValue("@classificacao_indicativa", categoria.classificacao_indicativa);
                comando.Parameters.AddWithValue("@faixa_etaria", categoria.faixa_etaria);
                comando.Parameters.AddWithValue("@publico_alvo", categoria.publico_alvo);
                comando.Parameters.AddWithValue("@data_cadastro", categoria.data_cadastro);

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Categoria";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Categoria categoria)
        {
            string sql = "UPDATE Categoria SET " +
                "nome = @nome, descricao = @descricao, " +
                "classificacao_indicativa = @classificacao_indicativa, " +
                "faixa_etaria = @faixa_etaria, publico_alvo = @publico_alvo, " +
                "data_cadastro = @data_cadastro " +
                "WHERE categoria_id = @categoria_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@categoria_id", categoria.categoria_id);
                comando.Parameters.AddWithValue("@nome", categoria.nome);
                comando.Parameters.AddWithValue("@descricao", categoria.descricao);
                comando.Parameters.AddWithValue("@classificacao_indicativa", categoria.classificacao_indicativa);
                comando.Parameters.AddWithValue("@faixa_etaria", categoria.faixa_etaria);
                comando.Parameters.AddWithValue("@publico_alvo", categoria.publico_alvo);
                comando.Parameters.AddWithValue("@data_cadastro", categoria.data_cadastro);

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int categoria_id)
        {
            string sql = "DELETE FROM Categoria WHERE categoria_id = @categoria_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@categoria_id", categoria_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}
