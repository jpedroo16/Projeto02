﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class FuncionarioController
    {
        private DataBaseSqlServer banco;

        public FuncionarioController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Funcionario funcionario)
        {
            string sql = "INSERT INTO Funcionario " +
                "(nome, cpf, telefone, email, cargo, data_admissao, salario) " +
                "VALUES (@nome, @cpf, @telefone, @email, @cargo, @data_admissao, @salario)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@nome", funcionario.nome);
                comando.Parameters.AddWithValue("@cpf", funcionario.cpf);
                comando.Parameters.AddWithValue("@telefone", funcionario.telefone);
                comando.Parameters.AddWithValue("@email", funcionario.email);
                comando.Parameters.AddWithValue("@cargo", funcionario.cargo);
                comando.Parameters.AddWithValue("@data_admissao", funcionario.data_admissao);
                comando.Parameters.AddWithValue("@salario", funcionario.salario);

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Funcionario";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Funcionario funcionario)
        {
            string sql = "UPDATE Funcionario SET " +
                "nome = @nome, cpf = @cpf, telefone = @telefone, " +
                "email = @email, cargo = @cargo, " +
                "data_admissao = @data_admissao, salario = @salario " +
                "WHERE funcionario_id = @funcionario_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@funcionario_id", funcionario.funcionario_id);
                comando.Parameters.AddWithValue("@nome", funcionario.nome);
                comando.Parameters.AddWithValue("@cpf", funcionario.cpf);
                comando.Parameters.AddWithValue("@telefone", funcionario.telefone);
                comando.Parameters.AddWithValue("@email", funcionario.email);
                comando.Parameters.AddWithValue("@cargo", funcionario.cargo);
                comando.Parameters.AddWithValue("@data_admissao", funcionario.data_admissao);
                comando.Parameters.AddWithValue("@salario", funcionario.salario);

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int funcionario_id)
        {
            string sql = "DELETE FROM Funcionario WHERE funcionario_id = @funcionario_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@funcionario_id", funcionario_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}

