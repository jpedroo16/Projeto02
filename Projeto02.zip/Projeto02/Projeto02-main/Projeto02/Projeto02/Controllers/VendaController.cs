﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class VendaController
    {
        private DataBaseSqlServer banco;

        public VendaController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Venda venda)
        {
            string sql = "INSERT INTO Venda " +
                "(data_hora, cliente_id, funcionario_id, valor_total, forma_pagamento, status_venda) " +
                "VALUES (@data_hora, @cliente_id, @funcionario_id, @valor_total, @forma_pagamento, @status_venda)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@data_hora", venda.data_hora);
                comando.Parameters.AddWithValue("@cliente_id", venda.cliente_id);
                comando.Parameters.AddWithValue("@funcionario_id", venda.funcionario_id);
                comando.Parameters.AddWithValue("@valor_total", venda.valor_total);
                comando.Parameters.AddWithValue("@forma_pagamento", venda.forma_pagamento);
                comando.Parameters.AddWithValue("@status_venda", venda.status_venda);

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Venda";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Venda venda)
        {
            string sql = "UPDATE Venda SET " +
                "data_hora = @data_hora, cliente_id = @cliente_id, " +
                "funcionario_id = @funcionario_id, valor_total = @valor_total, " +
                "forma_pagamento = @forma_pagamento, status_venda = @status_venda " +
                "WHERE venda_id = @venda_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@venda_id", venda.venda_id);
                comando.Parameters.AddWithValue("@data_hora", venda.data_hora);
                comando.Parameters.AddWithValue("@cliente_id", venda.cliente_id);
                comando.Parameters.AddWithValue("@funcionario_id", venda.funcionario_id);
                comando.Parameters.AddWithValue("@valor_total", venda.valor_total);
                comando.Parameters.AddWithValue("@forma_pagamento", venda.forma_pagamento);
                comando.Parameters.AddWithValue("@status_venda", venda.status_venda);

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int venda_id)
        {
            string sql = "DELETE FROM Venda WHERE venda_id = @venda_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@venda_id", venda_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}

