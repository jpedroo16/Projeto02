﻿namespace Projeto02.Views
{
    partial class frmFuncionarioCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnApagarFuncionario = new System.Windows.Forms.Button();
            this.btnSalvarFuncionario = new System.Windows.Forms.Button();
            this.lblCodigoFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioFuncionario = new System.Windows.Forms.Label();
            this.txtCodigoFuncionario = new System.Windows.Forms.TextBox();
            this.txtEmailFuncionario = new System.Windows.Forms.TextBox();
            this.lblEmailFuncionario = new System.Windows.Forms.Label();
            this.lblCargoFuncionario = new System.Windows.Forms.Label();
            this.lblCpfFuncionario = new System.Windows.Forms.Label();
            this.lblTelefoneFuncionario = new System.Windows.Forms.Label();
            this.dtpAdmissaoFuncionario = new System.Windows.Forms.DateTimePicker();
            this.lblDataAdmissaoFuncionario = new System.Windows.Forms.Label();
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.txtSalarioFuncionario = new System.Windows.Forms.TextBox();
            this.txtTelefoneFuncionario = new System.Windows.Forms.TextBox();
            this.txtCargoFuncionario = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.jogosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jogosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jogosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.categoriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desenvolvedorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realizarVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itensDaVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtCpfFuncionario = new System.Windows.Forms.TextBox();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label1.Location = new System.Drawing.Point(616, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 27);
            this.label1.TabIndex = 62;
            this.label1.Text = "CADASTRO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label3.Location = new System.Drawing.Point(659, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 27);
            this.label3.TabIndex = 64;
            this.label3.Text = "DE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.label2.Location = new System.Drawing.Point(586, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(191, 27);
            this.label2.TabIndex = 63;
            this.label2.Text = "FUNCIONÁRIOS";
            // 
            // btnApagarFuncionario
            // 
            this.btnApagarFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.btnApagarFuncionario.FlatAppearance.BorderSize = 0;
            this.btnApagarFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApagarFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagarFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(86)))), ((int)(((byte)(216)))));
            this.btnApagarFuncionario.Location = new System.Drawing.Point(649, 407);
            this.btnApagarFuncionario.Name = "btnApagarFuncionario";
            this.btnApagarFuncionario.Size = new System.Drawing.Size(88, 26);
            this.btnApagarFuncionario.TabIndex = 61;
            this.btnApagarFuncionario.Text = "Apagar";
            this.btnApagarFuncionario.UseVisualStyleBackColor = false;
            this.btnApagarFuncionario.Click += new System.EventHandler(this.btnApagarFuncionario_Click);
            // 
            // btnSalvarFuncionario
            // 
            this.btnSalvarFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(86)))), ((int)(((byte)(216)))));
            this.btnSalvarFuncionario.FlatAppearance.BorderSize = 0;
            this.btnSalvarFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvarFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.btnSalvarFuncionario.Location = new System.Drawing.Point(545, 407);
            this.btnSalvarFuncionario.Name = "btnSalvarFuncionario";
            this.btnSalvarFuncionario.Size = new System.Drawing.Size(88, 26);
            this.btnSalvarFuncionario.TabIndex = 60;
            this.btnSalvarFuncionario.Text = "Salvar";
            this.btnSalvarFuncionario.UseVisualStyleBackColor = false;
            this.btnSalvarFuncionario.Click += new System.EventHandler(this.btnSalvarFuncionario_Click);
            // 
            // lblCodigoFuncionario
            // 
            this.lblCodigoFuncionario.AutoSize = true;
            this.lblCodigoFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblCodigoFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblCodigoFuncionario.Location = new System.Drawing.Point(421, 336);
            this.lblCodigoFuncionario.Name = "lblCodigoFuncionario";
            this.lblCodigoFuncionario.Size = new System.Drawing.Size(57, 18);
            this.lblCodigoFuncionario.TabIndex = 59;
            this.lblCodigoFuncionario.Text = "Código";
            // 
            // lblSalarioFuncionario
            // 
            this.lblSalarioFuncionario.AutoSize = true;
            this.lblSalarioFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblSalarioFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblSalarioFuncionario.Location = new System.Drawing.Point(423, 282);
            this.lblSalarioFuncionario.Name = "lblSalarioFuncionario";
            this.lblSalarioFuncionario.Size = new System.Drawing.Size(55, 18);
            this.lblSalarioFuncionario.TabIndex = 58;
            this.lblSalarioFuncionario.Text = "Salário";
            // 
            // txtCodigoFuncionario
            // 
            this.txtCodigoFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtCodigoFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodigoFuncionario.Location = new System.Drawing.Point(424, 356);
            this.txtCodigoFuncionario.Multiline = true;
            this.txtCodigoFuncionario.Name = "txtCodigoFuncionario";
            this.txtCodigoFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtCodigoFuncionario.TabIndex = 57;
            // 
            // txtEmailFuncionario
            // 
            this.txtEmailFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtEmailFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmailFuncionario.Location = new System.Drawing.Point(47, 356);
            this.txtEmailFuncionario.Multiline = true;
            this.txtEmailFuncionario.Name = "txtEmailFuncionario";
            this.txtEmailFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtEmailFuncionario.TabIndex = 56;
            // 
            // lblEmailFuncionario
            // 
            this.lblEmailFuncionario.AutoSize = true;
            this.lblEmailFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblEmailFuncionario.Location = new System.Drawing.Point(44, 336);
            this.lblEmailFuncionario.Name = "lblEmailFuncionario";
            this.lblEmailFuncionario.Size = new System.Drawing.Size(51, 18);
            this.lblEmailFuncionario.TabIndex = 55;
            this.lblEmailFuncionario.Text = "E-mail";
            this.lblEmailFuncionario.Click += new System.EventHandler(this.lblEmailCliente_Click);
            // 
            // lblCargoFuncionario
            // 
            this.lblCargoFuncionario.AutoSize = true;
            this.lblCargoFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblCargoFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargoFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblCargoFuncionario.Location = new System.Drawing.Point(423, 229);
            this.lblCargoFuncionario.Name = "lblCargoFuncionario";
            this.lblCargoFuncionario.Size = new System.Drawing.Size(50, 18);
            this.lblCargoFuncionario.TabIndex = 54;
            this.lblCargoFuncionario.Text = "Cargo";
            // 
            // lblCpfFuncionario
            // 
            this.lblCpfFuncionario.AutoSize = true;
            this.lblCpfFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblCpfFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpfFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblCpfFuncionario.Location = new System.Drawing.Point(44, 282);
            this.lblCpfFuncionario.Name = "lblCpfFuncionario";
            this.lblCpfFuncionario.Size = new System.Drawing.Size(34, 18);
            this.lblCpfFuncionario.TabIndex = 53;
            this.lblCpfFuncionario.Text = "CPF";
            this.lblCpfFuncionario.Click += new System.EventHandler(this.lblCpfCliente_Click);
            // 
            // lblTelefoneFuncionario
            // 
            this.lblTelefoneFuncionario.AutoSize = true;
            this.lblTelefoneFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefoneFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblTelefoneFuncionario.Location = new System.Drawing.Point(44, 228);
            this.lblTelefoneFuncionario.Name = "lblTelefoneFuncionario";
            this.lblTelefoneFuncionario.Size = new System.Drawing.Size(67, 18);
            this.lblTelefoneFuncionario.TabIndex = 52;
            this.lblTelefoneFuncionario.Text = "Telefone";
            // 
            // dtpAdmissaoFuncionario
            // 
            this.dtpAdmissaoFuncionario.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAdmissaoFuncionario.CalendarForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpAdmissaoFuncionario.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dtpAdmissaoFuncionario.CalendarTrailingForeColor = System.Drawing.Color.DimGray;
            this.dtpAdmissaoFuncionario.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAdmissaoFuncionario.Location = new System.Drawing.Point(424, 198);
            this.dtpAdmissaoFuncionario.Name = "dtpAdmissaoFuncionario";
            this.dtpAdmissaoFuncionario.Size = new System.Drawing.Size(311, 20);
            this.dtpAdmissaoFuncionario.TabIndex = 51;
            // 
            // lblDataAdmissaoFuncionario
            // 
            this.lblDataAdmissaoFuncionario.AutoSize = true;
            this.lblDataAdmissaoFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblDataAdmissaoFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataAdmissaoFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblDataAdmissaoFuncionario.Location = new System.Drawing.Point(421, 176);
            this.lblDataAdmissaoFuncionario.Name = "lblDataAdmissaoFuncionario";
            this.lblDataAdmissaoFuncionario.Size = new System.Drawing.Size(136, 18);
            this.lblDataAdmissaoFuncionario.TabIndex = 50;
            this.lblDataAdmissaoFuncionario.Text = "Data de Admissão";
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.BackColor = System.Drawing.Color.Transparent;
            this.lblNomeFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.lblNomeFuncionario.Location = new System.Drawing.Point(44, 175);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(48, 18);
            this.lblNomeFuncionario.TabIndex = 49;
            this.lblNomeFuncionario.Text = "Nome";
            // 
            // txtSalarioFuncionario
            // 
            this.txtSalarioFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtSalarioFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSalarioFuncionario.Location = new System.Drawing.Point(424, 303);
            this.txtSalarioFuncionario.Multiline = true;
            this.txtSalarioFuncionario.Name = "txtSalarioFuncionario";
            this.txtSalarioFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtSalarioFuncionario.TabIndex = 48;
            // 
            // txtTelefoneFuncionario
            // 
            this.txtTelefoneFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtTelefoneFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefoneFuncionario.Location = new System.Drawing.Point(47, 249);
            this.txtTelefoneFuncionario.Multiline = true;
            this.txtTelefoneFuncionario.Name = "txtTelefoneFuncionario";
            this.txtTelefoneFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtTelefoneFuncionario.TabIndex = 47;
            // 
            // txtCargoFuncionario
            // 
            this.txtCargoFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtCargoFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCargoFuncionario.Location = new System.Drawing.Point(424, 247);
            this.txtCargoFuncionario.Multiline = true;
            this.txtCargoFuncionario.Name = "txtCargoFuncionario";
            this.txtCargoFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtCargoFuncionario.TabIndex = 46;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(45)))));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jogosToolStripMenuItem,
            this.jogosToolStripMenuItem1,
            this.cadastrosToolStripMenuItem,
            this.vendasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(222, 17);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(455, 28);
            this.menuStrip1.TabIndex = 40;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // jogosToolStripMenuItem
            // 
            this.jogosToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.jogosToolStripMenuItem.Name = "jogosToolStripMenuItem";
            this.jogosToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.jogosToolStripMenuItem.Text = "Início";
            // 
            // jogosToolStripMenuItem1
            // 
            this.jogosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jogosToolStripMenuItem2,
            this.categoriasToolStripMenuItem});
            this.jogosToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.jogosToolStripMenuItem1.Name = "jogosToolStripMenuItem1";
            this.jogosToolStripMenuItem1.Size = new System.Drawing.Size(71, 24);
            this.jogosToolStripMenuItem1.Text = "Jogos";
            // 
            // jogosToolStripMenuItem2
            // 
            this.jogosToolStripMenuItem2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.jogosToolStripMenuItem2.Name = "jogosToolStripMenuItem2";
            this.jogosToolStripMenuItem2.Size = new System.Drawing.Size(169, 24);
            this.jogosToolStripMenuItem2.Text = "Jogos";
            // 
            // categoriasToolStripMenuItem
            // 
            this.categoriasToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.categoriasToolStripMenuItem.Name = "categoriasToolStripMenuItem";
            this.categoriasToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
            this.categoriasToolStripMenuItem.Text = "Categorias";
            // 
            // cadastrosToolStripMenuItem
            // 
            this.cadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.desenvolvedorasToolStripMenuItem});
            this.cadastrosToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            this.cadastrosToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
            this.cadastrosToolStripMenuItem.Text = "Cadastros";
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.clientesToolStripMenuItem.Text = "Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.funcionáriosToolStripMenuItem.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem_Click);
            // 
            // desenvolvedorasToolStripMenuItem
            // 
            this.desenvolvedorasToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(165)))), ((int)(((byte)(65)))));
            this.desenvolvedorasToolStripMenuItem.Name = "desenvolvedorasToolStripMenuItem";
            this.desenvolvedorasToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.desenvolvedorasToolStripMenuItem.Text = "Desenvolvedoras";
            this.desenvolvedorasToolStripMenuItem.Click += new System.EventHandler(this.desenvolvedorasToolStripMenuItem_Click);
            // 
            // vendasToolStripMenuItem
            // 
            this.vendasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.realizarVendaToolStripMenuItem,
            this.consultarVendaToolStripMenuItem,
            this.itensDaVendaToolStripMenuItem});
            this.vendasToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.vendasToolStripMenuItem.Name = "vendasToolStripMenuItem";
            this.vendasToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.vendasToolStripMenuItem.Text = "Vendas";
            // 
            // realizarVendaToolStripMenuItem
            // 
            this.realizarVendaToolStripMenuItem.Name = "realizarVendaToolStripMenuItem";
            this.realizarVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.realizarVendaToolStripMenuItem.Text = "Realizar Venda";
            // 
            // consultarVendaToolStripMenuItem
            // 
            this.consultarVendaToolStripMenuItem.Name = "consultarVendaToolStripMenuItem";
            this.consultarVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.consultarVendaToolStripMenuItem.Text = "Consultar Venda";
            // 
            // itensDaVendaToolStripMenuItem
            // 
            this.itensDaVendaToolStripMenuItem.Name = "itensDaVendaToolStripMenuItem";
            this.itensDaVendaToolStripMenuItem.Size = new System.Drawing.Size(217, 24);
            this.itensDaVendaToolStripMenuItem.Text = "Itens da Venda";
            // 
            // txtCpfFuncionario
            // 
            this.txtCpfFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtCpfFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCpfFuncionario.Location = new System.Drawing.Point(47, 303);
            this.txtCpfFuncionario.Multiline = true;
            this.txtCpfFuncionario.Name = "txtCpfFuncionario";
            this.txtCpfFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtCpfFuncionario.TabIndex = 45;
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(61)))), ((int)(((byte)(74)))));
            this.txtNomeFuncionario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomeFuncionario.Location = new System.Drawing.Point(47, 196);
            this.txtNomeFuncionario.Multiline = true;
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(311, 23);
            this.txtNomeFuncionario.TabIndex = 44;
            this.txtNomeFuncionario.TextChanged += new System.EventHandler(this.txtNomeFuncionario_TextChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(560, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 3);
            this.panel2.TabIndex = 42;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(235)))), ((int)(((byte)(242)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(12, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 3);
            this.panel1.TabIndex = 41;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Projeto02.Properties.Resources.banner1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(802, 124);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // frmFuncionarioCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnApagarFuncionario);
            this.Controls.Add(this.btnSalvarFuncionario);
            this.Controls.Add(this.lblCodigoFuncionario);
            this.Controls.Add(this.lblSalarioFuncionario);
            this.Controls.Add(this.txtCodigoFuncionario);
            this.Controls.Add(this.txtEmailFuncionario);
            this.Controls.Add(this.lblEmailFuncionario);
            this.Controls.Add(this.lblCargoFuncionario);
            this.Controls.Add(this.lblCpfFuncionario);
            this.Controls.Add(this.lblTelefoneFuncionario);
            this.Controls.Add(this.dtpAdmissaoFuncionario);
            this.Controls.Add(this.lblDataAdmissaoFuncionario);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Controls.Add(this.txtSalarioFuncionario);
            this.Controls.Add(this.txtTelefoneFuncionario);
            this.Controls.Add(this.txtCargoFuncionario);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.txtCpfFuncionario);
            this.Controls.Add(this.txtNomeFuncionario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmFuncionarioCadastro";
            this.Text = "frmFuncionario";
            this.Load += new System.EventHandler(this.frmFuncionarioCadastro_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnApagarFuncionario;
        private System.Windows.Forms.Button btnSalvarFuncionario;
        private System.Windows.Forms.Label lblCodigoFuncionario;
        private System.Windows.Forms.Label lblSalarioFuncionario;
        private System.Windows.Forms.TextBox txtCodigoFuncionario;
        private System.Windows.Forms.TextBox txtEmailFuncionario;
        private System.Windows.Forms.Label lblEmailFuncionario;
        private System.Windows.Forms.Label lblCargoFuncionario;
        private System.Windows.Forms.Label lblCpfFuncionario;
        private System.Windows.Forms.Label lblTelefoneFuncionario;
        private System.Windows.Forms.DateTimePicker dtpAdmissaoFuncionario;
        private System.Windows.Forms.Label lblDataAdmissaoFuncionario;
        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.TextBox txtSalarioFuncionario;
        private System.Windows.Forms.TextBox txtTelefoneFuncionario;
        private System.Windows.Forms.TextBox txtCargoFuncionario;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jogosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem categoriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desenvolvedorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem realizarVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itensDaVendaToolStripMenuItem;
        private System.Windows.Forms.TextBox txtCpfFuncionario;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}