﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Projeto02.Models
{
    public class Funcionario
    {
        public int funcionario_id { get; set; }
        public string nome { get; set; }
        public string cpf { get; set; }
        public string telefone { get; set; }
        public string email { get; set; }
        public string cargo { get; set; }
        public DateTime data_admissao { get; set; }
        public decimal salario { get; set; }
    }
}
