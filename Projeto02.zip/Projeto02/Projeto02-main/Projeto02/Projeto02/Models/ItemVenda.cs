﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Projeto02.Models
{
    public class ItemVenda
    {
        public int item_venda_id { get; set; }
        public int venda_id { get; set; }
        public int jogo_id { get; set; }
        public int quantidade { get; set; }
        public decimal preco_unitario { get; set; }
        public decimal valor_total { get; set; }
        public decimal desconto { get; set; }
    }
}

