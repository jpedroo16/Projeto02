﻿
using Projeto02.Controllers;
using Projeto02.Models;
using System;
using System.Windows.Forms;

namespace Projeto02.Views
{
    public partial class frmDesenvolvedoraCadastro : Form
    {
        DesenvolvedoraController desenvolvedoraController = new DesenvolvedoraController();

        public frmDesenvolvedoraCadastro()
        {
            InitializeComponent();
        }

        private bool ValidarCampos()
        {
            if (txtNomeDesenvolvedora.Text.Trim() == "" ||
                txtPaisDesenvolvedora.Text.Trim() == "" ||
                txtCidadeDesenvolvedora.Text.Trim() == "" ||
                txtEmailDesenvolvedora.Text.Trim() == "" ||
                txtTelefoneDesenvolvedora.Text.Trim() == "" ||
                txtNomeResponsavelDesenvolvedora.Text.Trim() == "")
            {
                MessageBox.Show(
                    "Preencha todos os campos!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            string telefone = txtTelefoneDesenvolvedora.Text
                .Replace("(", "")
                .Replace(")", "")
                .Replace("-", "")
                .Replace(" ", "");

            long numeroTelefone;

            if ((telefone.Length != 10 && telefone.Length != 11) ||
                !long.TryParse(telefone, out numeroTelefone))
            {
                MessageBox.Show(
                    "O telefone deve conter 10 ou 11 números, incluindo o DDD!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtTelefoneDesenvolvedora.Focus();
                return false;
            }

            if (!txtEmailDesenvolvedora.Text.Contains("@"))
            {
                MessageBox.Show(
                    "E-mail inválido! Informe um endereço que contenha @.",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtEmailDesenvolvedora.Focus();
                return false;
            }

            return true;
        }

        private void btnSalvarDesenvolvedora_Click(object sender, EventArgs e)
        {
            if (ValidarCampos() == false)
                return;

            Desenvolvedora desenvolvedora = new Desenvolvedora();

            desenvolvedora.nome = txtNomeDesenvolvedora.Text;
            desenvolvedora.pais = txtPaisDesenvolvedora.Text;
            desenvolvedora.cidade = txtCidadeDesenvolvedora.Text;
            desenvolvedora.email = txtEmailDesenvolvedora.Text;
            desenvolvedora.telefone = txtTelefoneDesenvolvedora.Text;
            desenvolvedora.nome_responsavel = txtNomeResponsavelDesenvolvedora.Text;
            desenvolvedora.data_fundacao = dtpFundacaoDesenvolvedora.Value;

            int retorno = desenvolvedoraController.Adicionar(desenvolvedora);

            if (retorno > 0)
            {
                MessageBox.Show(
                    "Desenvolvedora cadastrada com sucesso!",
                    "Informação!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
                MessageBox.Show(
                    "Falha ao cadastrar a desenvolvedora!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
        }

        private void btnApagarDesenvolvedora_Click(object sender, EventArgs e)
        {
            txtCodigoDesenvolvedora.Clear();
            txtNomeDesenvolvedora.Clear();
            txtPaisDesenvolvedora.Clear();
            txtCidadeDesenvolvedora.Clear();
            txtEmailDesenvolvedora.Clear();
            txtTelefoneDesenvolvedora.Clear();
            txtNomeResponsavelDesenvolvedora.Clear();

            dtpFundacaoDesenvolvedora.Value = DateTime.Today;
        }

        private void desenvolvedorasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmFuncionarioCadastro funcionario = new frmFuncionarioCadastro();
            funcionario.ShowDialog();

            this.Show();
        }

        private void txtTelefoneDesenvolvedora_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
