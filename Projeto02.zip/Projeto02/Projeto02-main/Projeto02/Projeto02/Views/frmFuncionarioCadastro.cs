﻿
using Projeto02.Controllers;
using Projeto02.Models;
using System;
using System.Windows.Forms;

namespace Projeto02.Views
{
    public partial class frmFuncionarioCadastro : Form
    {
        FuncionarioController funcionarioController = new FuncionarioController();

        public frmFuncionarioCadastro()
        {
            InitializeComponent();
        }

        private bool ValidarCampos()
        {
            if (txtNomeFuncionario.Text.Trim() == "" ||
                txtCargoFuncionario.Text.Trim() == "" ||
                txtTelefoneFuncionario.Text.Trim() == "" ||
                txtSalarioFuncionario.Text.Trim() == "" ||
                txtCargoFuncionario.Text.Trim() == "" ||
                txtSalarioFuncionario.Text.Trim() == "")
            {
                MessageBox.Show(
                    "Preencha todos os campos!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            string cpf = txtCargoFuncionario.Text.Replace(".", "").Replace("-", "").Replace(" ", "");

            long numeroCPF;

            if (cpf.Length != 11 || !long.TryParse(cpf, out numeroCPF))
            {
                MessageBox.Show(
                    "O CPF deve conter 11 números!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtCargoFuncionario.Focus();
                return false;
            }

            string telefone = txtTelefoneFuncionario.Text
                .Replace("(", "")
                .Replace(")", "")
                .Replace("-", "")
                .Replace(" ", "");

            long numeroTelefone;

            if ((telefone.Length != 10 && telefone.Length != 11) ||
                !long.TryParse(telefone, out numeroTelefone))
            {
                MessageBox.Show(
                    "O telefone deve conter 10 ou 11 números, incluindo o DDD!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtTelefoneFuncionario.Focus();
                return false;
            }

            if (!txtSalarioFuncionario.Text.Contains("@"))
            {
                MessageBox.Show(
                    "E-mail inválido! Informe um endereço que contenha @.",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtSalarioFuncionario.Focus();
                return false;
            }

            decimal salario;

            if (!decimal.TryParse(txtSalarioFuncionario.Text, out salario) || salario <= 0)
            {
                MessageBox.Show(
                    "Informe um salário válido!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtSalarioFuncionario.Focus();
                return false;
            }

            return true;
        }

        private void btnSalvarFuncionario_Click(object sender, EventArgs e)
        {
            if (ValidarCampos() == false)
                return;

            Funcionario funcionario = new Funcionario();

            funcionario.nome = txtNomeFuncionario.Text;
            funcionario.cpf = txtCargoFuncionario.Text;
            funcionario.telefone = txtTelefoneFuncionario.Text;
            funcionario.email = txtSalarioFuncionario.Text;
            funcionario.cargo = txtCargoFuncionario.Text;
            funcionario.data_admissao = dtpAdmissaoFuncionario.Value;
            funcionario.salario = decimal.Parse(txtSalarioFuncionario.Text);

            int retorno = funcionarioController.Adicionar(funcionario);

            if (retorno > 0)
            {
                MessageBox.Show(
                    "Funcionário cadastrado com sucesso!",
                    "Informação!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
                MessageBox.Show(
                    "Falha ao cadastrar o funcionário!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
        }

        private void btnApagarFuncionario_Click(object sender, EventArgs e)
        {
            txtCodigoFuncionario.Clear();
            txtNomeFuncionario.Clear();
            txtCargoFuncionario.Clear();
            txtTelefoneFuncionario.Clear();
            txtSalarioFuncionario.Clear();
            txtCargoFuncionario.Clear();
            txtSalarioFuncionario.Clear();

            dtpAdmissaoFuncionario.Value = DateTime.Today;
        }

        private void lblCpfCliente_Click(object sender, EventArgs e)
        {

        }

        private void lblEmailCliente_Click(object sender, EventArgs e)
        {

        }

        private void txtNomeFuncionario_TextChanged(object sender, EventArgs e)
        {

        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmFuncionarioCadastro funcionario = new frmFuncionarioCadastro();
            funcionario.ShowDialog();

            this.Show();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmClienteCadastro cliente = new frmClienteCadastro();
            cliente.ShowDialog();

            this.Show();
        }

        private void frmFuncionarioCadastro_Load(object sender, EventArgs e)
        {

        }

        private void desenvolvedorasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmDesenvolvedoraCadastro desenvolvedora = new frmDesenvolvedoraCadastro();
            desenvolvedora.ShowDialog();

            this.Show();
        }
    }
}
