﻿
using Projeto02.Controllers;
using Projeto02.Models;
using System;
using System.Windows.Forms;

namespace Projeto02.Views
{
    public partial class frmClienteCadastro : Form
    {
        ClienteController clienteController = new ClienteController();

        public frmClienteCadastro()
        {
            InitializeComponent();
        }

        private bool ValidarCampos()
        {
            if (txtNomeCliente.Text.Trim() == "" ||
                txtCpfCliente.Text.Trim() == "" ||
                txtTelefoneCliente.Text.Trim() == "" ||
                txtEmailCliente.Text.Trim() == "" ||
                txtEnderecoCliente.Text.Trim() == "" ||
                txtCidadeCliente.Text.Trim() == "")
            {
                MessageBox.Show(
                    "Preencha todos os campos!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            string cpf = txtCpfCliente.Text.Replace(".", "").Replace("-", "").Replace(" ", "");

            long numeroCPF;

            if (cpf.Length != 11 || !long.TryParse(cpf, out numeroCPF))
            {
                MessageBox.Show(
                    "O CPF deve conter 11 números!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtCpfCliente.Focus();
                return false;
            }

            string telefone = txtTelefoneCliente.Text
                .Replace("(", "")
                .Replace(")", "")
                .Replace("-", "")
                .Replace(" ", "");

            long numeroTelefone;

            if ((telefone.Length != 10 && telefone.Length != 11) ||
                !long.TryParse(telefone, out numeroTelefone))
            {
                MessageBox.Show(
                    "O telefone deve conter 10 ou 11 números, incluindo o DDD!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtTelefoneCliente.Focus();
                return false;
            }

            if (!txtEmailCliente.Text.Contains("@"))
            {
                MessageBox.Show(
                    "E-mail inválido! Informe um endereço que contenha @.",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtEmailCliente.Focus();
                return false;
            }

            return true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (ValidarCampos() == false)
                return;

            Cliente cliente = new Cliente();

            cliente.nome = txtNomeCliente.Text;
            cliente.cpf = txtCpfCliente.Text;
            cliente.telefone = txtTelefoneCliente.Text;
            cliente.email = txtEmailCliente.Text;
            cliente.endereco = txtEnderecoCliente.Text;
            cliente.cidade = txtCidadeCliente.Text;
            cliente.data_cadastro = dtpCadastroCliente.Value;

            int retorno = clienteController.Adicionar(cliente);

            if (retorno > 0)
            {
                MessageBox.Show(
                    "Cadastro salvo com sucesso!",
                    "Informação!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
                MessageBox.Show(
                    "Falha ao salvar o cadastro!",
                    "Atenção!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtCodigoCliente.Clear();
            txtNomeCliente.Clear();
            txtCpfCliente.Clear();
            txtTelefoneCliente.Clear();
            txtEmailCliente.Clear();
            txtEnderecoCliente.Clear();
            txtCidadeCliente.Clear();

            dtpCadastroCliente.Value = DateTime.Today;
        }

        private void jogosToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmClienteCadastro_Load(object sender, EventArgs e)
        {

        }

        private void txtEmailCliente_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmailCliente_Click(object sender, EventArgs e)
        {

        }

        private void lblEnderecoCliente_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dtpCadastroCliente_ValueChanged(object sender, EventArgs e)
        {

        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmFuncionarioCadastro funcionario = new frmFuncionarioCadastro();
            funcionario.ShowDialog();

            this.Show();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmClienteCadastro cliente = new frmClienteCadastro();
            cliente.ShowDialog();

            this.Show();
        }

        private void cadastrosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void desenvolvedorasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmDesenvolvedoraCadastro desenvolvedora = new frmDesenvolvedoraCadastro();
            desenvolvedora.ShowDialog();

            this.Show();
        }
    }
}
