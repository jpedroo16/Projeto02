﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System;
using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class DesenvolvedoraController
    {
        private DataBaseSqlServer banco;

        public DesenvolvedoraController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Desenvolvedora desenvolvedora)
        {
            string sql = "INSERT INTO Desenvolvedora " +
                "(nome, pais, cidade, email, telefone, nome_responsavel, data_fundacao) " +
                "VALUES (@nome, @pais, @cidade, @email, @telefone, @nome_responsavel, @data_fundacao)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@nome", desenvolvedora.nome);
                comando.Parameters.AddWithValue("@pais", desenvolvedora.pais);
                comando.Parameters.AddWithValue("@cidade", desenvolvedora.cidade);
                comando.Parameters.AddWithValue("@email", desenvolvedora.email);
                comando.Parameters.AddWithValue("@telefone", desenvolvedora.telefone);
                comando.Parameters.AddWithValue("@nome_responsavel", desenvolvedora.nome_responsavel);

                if (desenvolvedora.data_fundacao.HasValue)
                {
                    comando.Parameters.AddWithValue("@data_fundacao", desenvolvedora.data_fundacao.Value);
                }
                else
                {
                    comando.Parameters.AddWithValue("@data_fundacao", DBNull.Value);
                }

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Desenvolvedora";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Desenvolvedora desenvolvedora)
        {
            string sql = "UPDATE Desenvolvedora SET " +
                "nome = @nome, pais = @pais, cidade = @cidade, " +
                "email = @email, telefone = @telefone, " +
                "nome_responsavel = @nome_responsavel, data_fundacao = @data_fundacao " +
                "WHERE desenvolvedora_id = @desenvolvedora_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@desenvolvedora_id", desenvolvedora.desenvolvedora_id);
                comando.Parameters.AddWithValue("@nome", desenvolvedora.nome);
                comando.Parameters.AddWithValue("@pais", desenvolvedora.pais);
                comando.Parameters.AddWithValue("@cidade", desenvolvedora.cidade);
                comando.Parameters.AddWithValue("@email", desenvolvedora.email);
                comando.Parameters.AddWithValue("@telefone", desenvolvedora.telefone);
                comando.Parameters.AddWithValue("@nome_responsavel", desenvolvedora.nome_responsavel);

                if (desenvolvedora.data_fundacao.HasValue)
                {
                    comando.Parameters.AddWithValue("@data_fundacao", desenvolvedora.data_fundacao.Value);
                }
                else
                {
                    comando.Parameters.AddWithValue("@data_fundacao", DBNull.Value);
                }

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int desenvolvedora_id)
        {
            string sql = "DELETE FROM Desenvolvedora " +
                "WHERE desenvolvedora_id = @desenvolvedora_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@desenvolvedora_id", desenvolvedora_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}

