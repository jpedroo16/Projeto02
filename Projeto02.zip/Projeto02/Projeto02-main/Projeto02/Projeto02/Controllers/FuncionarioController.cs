﻿
using Projeto02.Models;
using Projeto02.Services;
using System.Data;
using System.Data.SqlClient;

namespace Projeto02.Controllers
{
    public class FuncionarioController
    {
        DataBaseSqlServer dataBase = new DataBaseSqlServer();

        public int Adicionar(Funcionario funcionario)
        {
            string query =
                "INSERT INTO Funcionario (nome, cpf, telefone, email, cargo, data_admissao, salario) " +
                "VALUES (@Nome, @Cpf, @Telefone, @Email, @Cargo, @DataAdmissao, @Salario)";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@Nome", funcionario.nome);
            command.Parameters.AddWithValue("@Cpf", funcionario.cpf);
            command.Parameters.AddWithValue("@Telefone", funcionario.telefone);
            command.Parameters.AddWithValue("@Email", funcionario.email);
            command.Parameters.AddWithValue("@Cargo", funcionario.cargo);
            command.Parameters.AddWithValue("@DataAdmissao", funcionario.data_admissao);
            command.Parameters.AddWithValue("@Salario", funcionario.salario);

            return dataBase.ExecuteSQL(command);
        }

        public int Alterar(Funcionario funcionario)
        {
            string query =
                "UPDATE Funcionario SET " +
                "nome = @Nome, " +
                "cpf = @Cpf, " +
                "telefone = @Telefone, " +
                "email = @Email, " +
                "cargo = @Cargo, " +
                "data_admissao = @DataAdmissao, " +
                "salario = @Salario " +
                "WHERE funcionario_id = @FuncionarioId";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@Nome", funcionario.nome);
            command.Parameters.AddWithValue("@Cpf", funcionario.cpf);
            command.Parameters.AddWithValue("@Telefone", funcionario.telefone);
            command.Parameters.AddWithValue("@Email", funcionario.email);
            command.Parameters.AddWithValue("@Cargo", funcionario.cargo);
            command.Parameters.AddWithValue("@DataAdmissao", funcionario.data_admissao);
            command.Parameters.AddWithValue("@Salario", funcionario.salario);
            command.Parameters.AddWithValue("@FuncionarioId", funcionario.funcionario_id);

            return dataBase.ExecuteSQL(command);
        }

        public int Excluir(int funcionario_id)
        {
            string query =
                "DELETE FROM Funcionario " +
                "WHERE funcionario_id = @FuncionarioId";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@FuncionarioId", funcionario_id);

            return dataBase.ExecuteSQL(command);
        }

        public DataTable Consultar()
        {
            string query =
                "SELECT * FROM Funcionario " +
                "ORDER BY nome";

            SqlCommand command = new SqlCommand(query);

            return dataBase.GetDataTable(command);
        }
    }
}
