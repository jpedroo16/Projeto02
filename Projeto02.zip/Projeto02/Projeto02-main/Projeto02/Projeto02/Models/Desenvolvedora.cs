﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Projeto02.Models
{
    public class Desenvolvedora
    {
        public int desenvolvedora_id { get; set; }
        public string nome { get; set; }
        public string pais { get; set; }
        public string cidade { get; set; }
        public string email { get; set; }
        public string telefone { get; set; }
        public string nome_responsavel { get; set; }
        public DateTime? data_fundacao { get; set; }
    }
}
