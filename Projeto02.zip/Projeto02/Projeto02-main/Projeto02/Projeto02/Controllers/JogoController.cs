﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class JogoController
    {
        private DataBaseSqlServer banco;

        public JogoController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Jogo jogo)
        {
            string sql = "INSERT INTO Jogo " +
                "(titulo, plataforma, genero, classificacao_indicativa, " +
                "ano_lancamento, quantidade, preco_venda, desenvolvedora_id, categoria_id) " +
                "VALUES (@titulo, @plataforma, @genero, @classificacao_indicativa, " +
                "@ano_lancamento, @quantidade, @preco_venda, @desenvolvedora_id, @categoria_id)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@titulo", jogo.titulo);
                comando.Parameters.AddWithValue("@plataforma", jogo.plataforma);
                comando.Parameters.AddWithValue("@genero", jogo.genero);
                comando.Parameters.AddWithValue("@classificacao_indicativa", jogo.classificacao_indicativa);
                comando.Parameters.AddWithValue("@ano_lancamento", jogo.ano_lancamento);
                comando.Parameters.AddWithValue("@quantidade", jogo.quantidade);
                comando.Parameters.AddWithValue("@preco_venda", jogo.preco_venda);
                comando.Parameters.AddWithValue("@desenvolvedora_id", jogo.desenvolvedora_id);
                comando.Parameters.AddWithValue("@categoria_id", jogo.categoria_id);

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Jogo";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Jogo jogo)
        {
            string sql = "UPDATE Jogo SET " +
                "titulo = @titulo, plataforma = @plataforma, genero = @genero, " +
                "classificacao_indicativa = @classificacao_indicativa, " +
                "ano_lancamento = @ano_lancamento, quantidade = @quantidade, " +
                "preco_venda = @preco_venda, desenvolvedora_id = @desenvolvedora_id, " +
                "categoria_id = @categoria_id " +
                "WHERE jogo_id = @jogo_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@jogo_id", jogo.jogo_id);
                comando.Parameters.AddWithValue("@titulo", jogo.titulo);
                comando.Parameters.AddWithValue("@plataforma", jogo.plataforma);
                comando.Parameters.AddWithValue("@genero", jogo.genero);
                comando.Parameters.AddWithValue("@classificacao_indicativa", jogo.classificacao_indicativa);
                comando.Parameters.AddWithValue("@ano_lancamento", jogo.ano_lancamento);
                comando.Parameters.AddWithValue("@quantidade", jogo.quantidade);
                comando.Parameters.AddWithValue("@preco_venda", jogo.preco_venda);
                comando.Parameters.AddWithValue("@desenvolvedora_id", jogo.desenvolvedora_id);
                comando.Parameters.AddWithValue("@categoria_id", jogo.categoria_id);

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int jogo_id)
        {
            string sql = "DELETE FROM Jogo WHERE jogo_id = @jogo_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@jogo_id", jogo_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}

