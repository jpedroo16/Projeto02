﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using Projeto02.Models;
using Projeto02.Services;

namespace Projeto02.Controllers
{
    public class ClienteController
    {
        private DataBaseSqlServer banco;

        public ClienteController()
        {
            banco = new DataBaseSqlServer();
        }

        public int Adicionar(Cliente cliente)
        {
            string sql = "INSERT INTO Cliente " +
                "(nome, cpf, telefone, email, endereco, cidade, data_cadastro) " +
                "VALUES (@nome, @cpf, @telefone, @email, @endereco, @cidade, @data_cadastro)";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@nome", cliente.nome);
                comando.Parameters.AddWithValue("@cpf", cliente.cpf);
                comando.Parameters.AddWithValue("@telefone", cliente.telefone);
                comando.Parameters.AddWithValue("@email", cliente.email);
                comando.Parameters.AddWithValue("@endereco", cliente.endereco);
                comando.Parameters.AddWithValue("@cidade", cliente.cidade);
                comando.Parameters.AddWithValue("@data_cadastro", cliente.data_cadastro);

                return banco.ExecuteSQL(comando);
            }
        }

        public DataTable Consultar()
        {
            string sql = "SELECT * FROM Cliente";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                return banco.GetDataTable(comando);
            }
        }

        public int Alterar(Cliente cliente)
        {
            string sql = "UPDATE Cliente SET " +
                "nome = @nome, cpf = @cpf, telefone = @telefone, " +
                "email = @email, endereco = @endereco, cidade = @cidade, " +
                "data_cadastro = @data_cadastro " +
                "WHERE cliente_id = @cliente_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@cliente_id", cliente.cliente_id);
                comando.Parameters.AddWithValue("@nome", cliente.nome);
                comando.Parameters.AddWithValue("@cpf", cliente.cpf);
                comando.Parameters.AddWithValue("@telefone", cliente.telefone);
                comando.Parameters.AddWithValue("@email", cliente.email);
                comando.Parameters.AddWithValue("@endereco", cliente.endereco);
                comando.Parameters.AddWithValue("@cidade", cliente.cidade);
                comando.Parameters.AddWithValue("@data_cadastro", cliente.data_cadastro);

                return banco.ExecuteSQL(comando);
            }
        }

        public int Excluir(int cliente_id)
        {
            string sql = "DELETE FROM Cliente WHERE cliente_id = @cliente_id";

            using (SqlCommand comando = new SqlCommand(sql))
            {
                comando.Parameters.AddWithValue("@cliente_id", cliente_id);

                return banco.ExecuteSQL(comando);
            }
        }
    }
}
