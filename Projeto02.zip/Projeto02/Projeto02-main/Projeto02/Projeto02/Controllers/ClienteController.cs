﻿
using Projeto02.Models;
using Projeto02.Services;
using System.Data;
using System.Data.SqlClient;

namespace Projeto02.Controllers
{
    public class ClienteController
    {
        DataBaseSqlServer banco = new DataBaseSqlServer();

        public int Adicionar(Cliente cliente)
        {
            string query =
                "INSERT INTO Cliente (nome, cpf, telefone, email, endereco, cidade, data_cadastro) " +
                "VALUES (@Nome, @Cpf, @Telefone, @Email, @Endereco, @Cidade, @DataCadastro)";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@Nome", cliente.nome);
            command.Parameters.AddWithValue("@Cpf", cliente.cpf);
            command.Parameters.AddWithValue("@Telefone", cliente.telefone);
            command.Parameters.AddWithValue("@Email", cliente.email);
            command.Parameters.AddWithValue("@Endereco", cliente.endereco);
            command.Parameters.AddWithValue("@Cidade", cliente.cidade);
            command.Parameters.AddWithValue("@DataCadastro", cliente.data_cadastro);

            return banco.ExecuteSQL(command);
        }

        public int Alterar(Cliente cliente)
        {
            string query =
                "UPDATE Cliente SET " +
                "nome = @Nome, " +
                "cpf = @Cpf, " +
                "telefone = @Telefone, " +
                "email = @Email, " +
                "endereco = @Endereco, " +
                "cidade = @Cidade, " +
                "data_cadastro = @DataCadastro " +
                "WHERE cliente_id = @ClienteId";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@Nome", cliente.nome);
            command.Parameters.AddWithValue("@Cpf", cliente.cpf);
            command.Parameters.AddWithValue("@Telefone", cliente.telefone);
            command.Parameters.AddWithValue("@Email", cliente.email);
            command.Parameters.AddWithValue("@Endereco", cliente.endereco);
            command.Parameters.AddWithValue("@Cidade", cliente.cidade);
            command.Parameters.AddWithValue("@DataCadastro", cliente.data_cadastro);
            command.Parameters.AddWithValue("@ClienteId", cliente.cliente_id);

            return banco.ExecuteSQL(command);
        }

        public int Excluir(int cliente_id)
        {
            string query =
                "DELETE FROM Cliente " +
                "WHERE cliente_id = @ClienteId";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@ClienteId", cliente_id);

            return banco.ExecuteSQL(command);
        }

        public DataTable Consultar()
        {
            string query =
                "SELECT * FROM Cliente " +
                "ORDER BY nome";

            SqlCommand command = new SqlCommand(query);

            return banco.GetDataTable(command);
        }
    }
}
