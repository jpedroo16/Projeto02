﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Projeto02.Models
{
    public class Categoria
    {
        public int categoria_id { get; set; }
        public string nome { get; set; }
        public string descricao { get; set; }
        public string classificacao_indicativa { get; set; }
        public string faixa_etaria { get; set; }
        public string publico_alvo { get; set; }
        public DateTime data_cadastro { get; set; }
    }
}
