﻿
using System.Data;
using System.Data.SqlClient;

namespace Projeto02.Services
{
    public class DataBaseSqlServer
    {
        private SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection();

            connection.ConnectionString =
                "Data Source=.\\SQLEXPRESS;" +
                "Initial Catalog=LojaJogos;" +
                "Integrated Security=SSPI;";

            connection.Open();

            return connection;
        }

        public int ExecuteSQL(SqlCommand command)
        {
            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;

                return command.ExecuteNonQuery();
            }
        }

        public object ExecuteScalar(SqlCommand command)
        {
            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;

                return command.ExecuteScalar();
            }
        }

        public DataTable GetDataTable(SqlCommand command)
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;

                using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command))
                {
                    sqlDataAdapter.Fill(dataTable);
                }
            }

            return dataTable;
        }
    }
}
