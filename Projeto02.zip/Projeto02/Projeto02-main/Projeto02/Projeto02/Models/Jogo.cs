﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Projeto02.Models
{
    public class Jogo
    {
        public int jogo_id { get; set; }
        public string titulo { get; set; }
        public string plataforma { get; set; }
        public string genero { get; set; }
        public string classificacao_indicativa { get; set; }
        public int ano_lancamento { get; set; }
        public int quantidade { get; set; }
        public decimal preco_venda { get; set; }
        public int desenvolvedora_id { get; set; }
        public int categoria_id { get; set; }
    }
}

