CREATE DATABASE LojaJogos;
GO

USE LojaJogos;
GO

CREATE TABLE Cliente
(
    cliente_id INT IDENTITY PRIMARY KEY,
    nome VARCHAR(250) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(250) NOT NULL,
    endereco VARCHAR(250) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    data_cadastro DATE NOT NULL
);

CREATE TABLE Funcionario
(
    funcionario_id INT IDENTITY PRIMARY KEY,
    nome VARCHAR(250) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(250) NOT NULL,
    cargo VARCHAR(100) NOT NULL,
    data_admissao DATE NOT NULL,
    salario DECIMAL(10,2) NOT NULL
);

CREATE TABLE Desenvolvedora
(
    desenvolvedora_id INT IDENTITY PRIMARY KEY,
    nome VARCHAR(250) NOT NULL,
    pais VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    email VARCHAR(250) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    nome_responsavel VARCHAR(150) NOT NULL,
    data_fundacao DATE
);

CREATE TABLE Categoria
(
    categoria_id INT IDENTITY PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(250) NOT NULL,
    classificacao_indicativa VARCHAR(20) NOT NULL,
    faixa_etaria VARCHAR(50) NOT NULL,
    publico_alvo VARCHAR(100) NOT NULL,
    data_cadastro DATE NOT NULL
);

CREATE TABLE Jogo
(
    jogo_id INT IDENTITY PRIMARY KEY,
    titulo VARCHAR(250) NOT NULL,
    plataforma VARCHAR(100) NOT NULL,
    genero VARCHAR(100) NOT NULL,
    classificacao_indicativa VARCHAR(20) NOT NULL,
    ano_lancamento INT NOT NULL,
    quantidade INT NOT NULL,
    preco_venda DECIMAL(10,2) NOT NULL,
    desenvolvedora_id INT NOT NULL,
    categoria_id INT NOT NULL,

    FOREIGN KEY (desenvolvedora_id) REFERENCES Desenvolvedora(desenvolvedora_id),
    FOREIGN KEY (categoria_id) REFERENCES Categoria(categoria_id)
);

CREATE TABLE Venda
(
    venda_id INT IDENTITY PRIMARY KEY,
    data_hora DATETIME NOT NULL,
    cliente_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    forma_pagamento VARCHAR(50) NOT NULL,
    status_venda VARCHAR(20) NOT NULL,

    FOREIGN KEY (cliente_id) REFERENCES Cliente(cliente_id),
    FOREIGN KEY (funcionario_id) REFERENCES Funcionario(funcionario_id)
);

CREATE TABLE ItemVenda
(
    item_venda_id INT IDENTITY PRIMARY KEY,
    venda_id INT NOT NULL,
    jogo_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    desconto DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (venda_id) REFERENCES Venda(venda_id),
    FOREIGN KEY (jogo_id) REFERENCES Jogo(jogo_id)
);
GO